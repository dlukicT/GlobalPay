﻿using GlobalPayments.Api;
using GlobalPayments.Api.Entities;
using GlobalPayments.Api.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace GlobalPayment.Controllers.API
{
    public class GlobalPaymentController : ApiController
    {

        private string timestamp;
        public string MerchatId = "gpsalesdemo";
        public string Amount = "123.45";
        public string Currency = "USD";
        public string SharedSecret = "secret";
        public string GetTimeStamp()
        {
            if (timestamp is null)
            {
                timestamp = CalcTimeStamp();
            }

            return timestamp;
        }

        public string GetHash()
        {
            return Sha1Hash.GetSHA1Hash(GetTimeStamp(), MerchatId, OrderId, Amount, Currency, SharedSecret);
        }

        private string _OrderId;

        public string OrderId
        {
            get
            {
                if (_OrderId is null)
                {
                    _OrderId = GetOrderId();
                }
                return _OrderId;
            }
            set
            {
                _OrderId = value;
            }
        }

        private string CalcTimeStamp()
        {
            //20201126104422
            string hour = DateTime.Now.Hour > 9 ? DateTime.Now.Hour.ToString() : "0" + DateTime.Now.Hour.ToString();
            string min = DateTime.Now.Minute > 9 ? DateTime.Now.Minute.ToString() : "0" + DateTime.Now.Minute.ToString();
            string day = DateTime.Now.Day > 9 ? DateTime.Now.Day.ToString() : "0" + DateTime.Now.Day.ToString();
            string month = DateTime.Now.Month > 9 ? DateTime.Now.Month.ToString() : "0" + DateTime.Now.Month.ToString();

            string ts = DateTime.Now.Year.ToString() + month + day + hour + min + "00";
            return ts;
        }

        private string GetOrderId()
        {
            Random r = new Random(1000);
            Guid guid = Guid.NewGuid();
            int rnd = r.Next();
            return "ORDID_" + guid.ToString().Substring(0, 4) + "_" + rnd.ToString();
        }
        // GET api/<controller>
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }

        // GET api/<controller>/5
        public string Get(int id)
        {
            return "value";
        }
        [HttpGet]
        [Route("api/GlobalPayment/GetJson")]
        public string GetJson()
        {
            // configure client, request and HPP settings
            var service = new HostedService(new GpEcomConfig
            {
                MerchantId = "gpsalesdemo",
                AccountId = "internet",
                SharedSecret = "secret",
                ServiceUrl = "https://pay.sandbox.realexpayments.com/pay",
                HostedPaymentConfig = new HostedPaymentConfig
                {
                    Version = "2"
                }
            });

            // Add 3D Secure 2 Mandatory and Recommended Fields
            var hostedPaymentData = new HostedPaymentData
            {
                CustomerEmail = "james.mason@example.com",
                CustomerPhoneMobile = "44|07123456789",
                AddressesMatch = false
            };

            var billingAddress = new Address
            {
                StreetAddress1 = "Flat 123",
                StreetAddress2 = "House 456",
                StreetAddress3 = "Unit 4",
                City = "Halifax",
                PostalCode = "W5 9HR",
                Country = "826"
            };

            var shippingAddress = new Address
            {
                StreetAddress1 = "Apartment 825",
                StreetAddress2 = "Complex 741",
                StreetAddress3 = "House 963",
                City = "Chicago",
                State = "IL",
                PostalCode = "50001",
                Country = "840",
            };

            string hppJson = "";
            try
            {
                hppJson = service.Charge(9)
                  .WithCurrency("EUR")
                  //.WithHostedPaymentData(hostedPaymentData)
                  //.WithAddress(billingAddress, AddressType.Billing)
                  //.WithAddress(shippingAddress, AddressType.Shipping)
                  .WithOrderId(GetOrderNo())
                  .WithTimestamp(GetTimeStamp())
                  .Serialize();

                // TODO: pass the HPP request JSON to the JavaScript, iOS or Android Library
            }

            catch (ApiException exce)
            {
                // TODO: Add your error handling here
            }
            return hppJson;
        }

        [HttpGet]
        [Route("api/GlobalPayment/GetJSONoBJ")]
        public object GetJSONobj()
        {
            // configure client, request and HPP settings
            var service = new HostedService(new GpEcomConfig
            {
                MerchantId = "gpsalesdemo",
                AccountId = "internet",
                SharedSecret = "secret",
                ServiceUrl = "https://pay.sandbox.realexpayments.com/pay",
                HostedPaymentConfig = new HostedPaymentConfig
                {
                    Version = "2"
                }
            });

            // Add 3D Secure 2 Mandatory and Recommended Fields
            var hostedPaymentData = new HostedPaymentData
            {
                CustomerEmail = "james.mason@example.com",
                CustomerPhoneMobile = "44|07123456789",
                AddressesMatch = false
            };

            var billingAddress = new Address
            {
                StreetAddress1 = "Flat 123",
                StreetAddress2 = "House 456",
                StreetAddress3 = "Unit 4",
                City = "Halifax",
                PostalCode = "W5 9HR",
                Country = "826"
            };

            var shippingAddress = new Address
            {
                StreetAddress1 = "Apartment 825",
                StreetAddress2 = "Complex 741",
                StreetAddress3 = "House 963",
                City = "Chicago",
                State = "IL",
                PostalCode = "50001",
                Country = "840",
            };

            string hppJson = "";
            try
            {
                hppJson = service.Charge(9)
                  .WithCurrency("EUR")
                    //.WithHostedPaymentData(hostedPaymentData)
                    //.WithAddress(billingAddress, AddressType.Billing)
                    //.WithAddress(shippingAddress, AddressType.Shipping)
                    .WithOrderId(GetOrderNo())
                   .WithTimestamp(GetTimeStamp())
                  .Serialize();

                // TODO: pass the HPP request JSON to the JavaScript, iOS or Android Library
            }

            catch (ApiException exce)
            {
                // TODO: Add your error handling here
            }
            //Newtonsoft.Json.JsonConvert.SerializeObject(p);

            return Newtonsoft.Json.JsonConvert.DeserializeObject(hppJson); ;
        }

        //private string GetTimeStamp()
        //{
        //    //20201126104422
        //    string hour = DateTime.Now.Hour > 9 ? DateTime.Now.Hour.ToString() : "0" + DateTime.Now.Hour.ToString();
        //    string min = DateTime.Now.Minute > 9 ? DateTime.Now.Minute.ToString() : "0" + DateTime.Now.Minute.ToString();
        //    string day = DateTime.Now.Day > 9 ? DateTime.Now.Day.ToString() : "0" + DateTime.Now.Day.ToString();
        //    string month = DateTime.Now.Month > 9 ? DateTime.Now.Month.ToString() : "0" + DateTime.Now.Month.ToString();

        //    string ts = DateTime.Now.Year.ToString() + month + day + hour + min + "00";
        //    return ts;
        //}

        private string GetOrderNo()
        {
            Random r = new Random(1000);
            Guid guid = Guid.NewGuid();
            int rnd = r.Next();
            return "ORDID_" + guid.ToString().Substring(0,4) + "_" + rnd.ToString();
        }


        // POST api/<controller>
        public void Post([FromBody]string value)
        {
        }

        // PUT api/<controller>/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/<controller>/5
        public void Delete(int id)
        {
        }
    }
}