﻿using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Web;

namespace GlobalPayment
{
    public class Sha1Hash
    {
        public static string Hash(string input)
        {
            var hash = new SHA1Managed().ComputeHash(Encoding.UTF8.GetBytes(input));
            return string.Concat(hash.Select(b => b.ToString("x2")));
        }
        public static string Step1(string timestamp, string merchantid, string orderid, string amount, string currency, string sharedSecret)
        {
            //timestamp.merchantid.orderid.amount.currency
            string temp = timestamp + "." + merchantid + "." + amount + "." + currency;
            string tempHash = Hash(temp);
            string retHash = Step2(tempHash,sharedSecret);
            return retHash;
        }
        public static string Step2(string step1, string sharedSecret)
        {
            string sharedSecretHash = Hash(sharedSecret);
            string temp = step1 + sharedSecretHash;
            return Hash(temp);
        }
         public static string GetSHA1Hash(string timestamp, string merchantid, string orderid, string amount, string currency, string sharedSecret)
        {
            return Step1(timestamp, merchantid, orderid, amount, currency, sharedSecret);
        }
    }
}