﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace GlobalPayment
{
    public partial class UCCCform : System.Web.UI.UserControl
    {
        private string timestamp;
        public string MerchatId = "gpsalesdemo";
        public string Amount = "123.45";
        public string Currency = "USD";
        public string SharedSecret = "secret";

        //protected void Page_Load(object sender, EventArgs e)
        //{

        //}

        public string GetTimeStamp()
        {
            if (timestamp is null)
            {
                timestamp = CalcTimeStamp();
            }

            return timestamp;
        }

        public string GetHash()
        {
            return Sha1Hash.GetSHA1Hash(GetTimeStamp(), MerchatId, OrderId, Amount, Currency, SharedSecret);
        }

        private string _OrderId;

        public string OrderId
        {
            get
            {
                if (_OrderId is null)
                {
                    _OrderId = GetOrderId();
                }
                return _OrderId;
            }
            set {
                _OrderId = value;
            }
        }

         private string CalcTimeStamp()
        {
            //20201126104422
            string hour = DateTime.Now.Hour > 9 ? DateTime.Now.Hour.ToString() : "0" + DateTime.Now.Hour.ToString();
            string min = DateTime.Now.Minute > 9 ? DateTime.Now.Minute.ToString() : "0" + DateTime.Now.Minute.ToString();
            string day = DateTime.Now.Day > 9 ? DateTime.Now.Day.ToString() : "0" + DateTime.Now.Day.ToString();
            string month = DateTime.Now.Month > 9 ? DateTime.Now.Month.ToString() : "0" + DateTime.Now.Month.ToString();

            string ts = DateTime.Now.Year.ToString() + month + day + hour + min + "00";
            return ts;
        }

        private string GetOrderId()
        {
            Random r = new Random(1000);
            Guid guid = Guid.NewGuid();
            int rnd = r.Next();
            return "ORDID_" + guid.ToString().Substring(0, 4) + "_" + rnd.ToString();
        }

    }
}